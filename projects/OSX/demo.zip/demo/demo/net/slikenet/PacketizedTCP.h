/*
 *  Copyright (c) 2017, SLikeSoft UG (haftungsbeschränkt)
 *
 *  This source code is licensed under the MIT-style license found in the
 *  license.txt file in the root directory of this source tree.
 *
 *
 *  Header file redirection to keep source compatibility with RakNet 4.082.
 */

#include "../include/slikenet/PacketizedTCP.h"
