//
//  AppDelegate.h
//  demo
//
//  Created by 宋庭聿 on 2020/10/19.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

